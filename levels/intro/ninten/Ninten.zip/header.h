extern Lights0 ninten_f3d_material_lights;
extern Vtx ninten_gfx_nintendo_logo_gfx64_0_mesh_vtx_0[3363];
extern Gfx ninten_gfx_nintendo_logo_gfx64_0_mesh_tri_0[];
extern Gfx mat_ninten_f3d_material[];
extern Gfx ninten_gfx_nintendo_logo_gfx64_0_mesh[];
